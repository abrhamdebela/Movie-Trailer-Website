import fresh_tomatoes
import media

"......creating the movie file and calling to media class ....."""
The_Boss_Baby_poster = media.movie(
    "The Boss Baby poster",
    "the story of Boss Baby",
    "https://youtu.be/O2Bsw3lrhvs",
    "https://upload.wikimedia.org/wikipedia/en/0/0e/The_Boss_Baby_poster.jpg")

Gal_Gadot_as_Wonder_Woman = media.movie(
    "Gal Gadot as Wonder Woman",
    "the story of Gal Gadot as Wonder Woman",
    "https://youtu.be/Tgk_63b-Mrw",
    "https://upload.wikimedia.org/wikipedia/en/e/e1/Gal_Gadot_as_Wonder_Woman.jpg")
A_Dog = media.movie(
    "Sing",
    "the story of A Dog",
    "https://youtu.be/C4y_h9xbyDE",
    "https://upload.wikimedia.org/wikipedia/en/b/bf/A_Dog%27s_Purpose_%28film%29.jpg")
"""....creating the movies variable to contain the movie file..."""
movies = [The_Boss_Baby_poster, Gal_Gadot_as_Wonder_Woman, A_Dog]

"""....open the movies...."""
fresh_tomatoes.open_movies_page(movies)
