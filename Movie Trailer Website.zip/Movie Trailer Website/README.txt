



''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                                                                                                           Abrham Debela   4/27/2017
The main goal of the project is creating the movie trail website.To developing the project I 
import fresh_tomatoes and webbrowser library and I wrote python code, its file name is entertainment.py and media.py.

 
inside the entertainment python file i importing fresh_tomatoes and media library and initializing  
the list of movies including their detail and then to contain the movie detail I declare �movies� as a variable, 
this variable is calling by fresh tomato library to open the movie detail, Which can help us to open the movie trial  url. 


Inside the media python file I creating the movie class and imported webbrowser. 
Inside the movie class I define the movie detail and I calling the self to open the url by the help of webbroweser library. 


Generally, the following python code (fresh_tomatoes.open_movies_page(movies)) help us to contain all the list of movie including its url. 
The following line of python code (def how_trailer(self):webbrowser.open(self.trailer_youtube_url))
play significant role to open the url movie trailer.

 

Step by step instruction to open the movie trial website
 Step 1    opens the right click the zip document and extract 
 Step  2   double click the html file to open the website or open entertainment_center.py and click run and select run the module

   

    

'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''






